from django.urls import path
from . import views

urlpatterns = [
    path('signup/', views.signup),
    path('login/', views.login),
    path('', views.individual_post),
    path('create', views.stinsert, name='create1'),
    path('edit/<int:id>', views.edit),  
    path('update/<int:id>', views.update, name='update'),
    path('delete/<int:id>', views.delete_st),
    path('add/', views.add1, name='addvalue'),

    
]
