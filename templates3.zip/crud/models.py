from django.db import models

# Create your models here.
class crudst(models.Model):
    stname = models.CharField(max_length = 200)
    stemail = models.EmailField(max_length = 100)
    staddress = models.CharField(max_length = 100)
    stgender = models.CharField(max_length=10)
    


