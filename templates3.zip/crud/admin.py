from django.contrib import admin
#from crud.models import crudst
from .models import crudst
# Register your models here.
admin.site.register(crudst)
