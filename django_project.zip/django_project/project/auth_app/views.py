from django.shortcuts import render
from django.http import HttpResponse
from django.contrib.auth.models import User, auth


# Create your views here.

def home(request):
    #return HttpResponse('Hi, this is where an individual post will be. mohit')
    return render(request, 'auth/home.html')

def login(request):
    return render(request, 'auth/login.html')

def signup(request):
    if request.method == 'POST':
        first_name = request.POST['first_name']
        first_name = request.POST['last_name']
        first_name = request.POST['user']
        first_name = request.POST['email']
        first_name = request.POST['password']
        first_name = request.POST['confirm_password']
    else:



    return render(request, 'auth/signup.html')