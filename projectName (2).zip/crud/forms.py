from django import forms
from crud.models import crudst
class crudform(forms.ModelForm):
    class Meta:
        model = crudst
        fiels = "__all__"