from django.shortcuts import render, redirect
from django.http import HttpResponse
from crud.models import crudst
#from crud.forms import crudst
from django.contrib import messages
#from crud.forms import crudform

# Create your views here.
def signup(request):
     return render(request,"signup.html")

def login(request):
     return render(request,"signin.html")


def individual_post(request):
    #return HttpResponse('Hi, this is where an individual post will be. mohit')
    stdata= crudst.objects.all()    
    context= {'showstdata': stdata}
    return render(request, 'index.html',context)
    

def home123(request):
     return render(request,"index.html")


def stinsert(request):
    if request.method=="POST":
        if request.POST.get('stname') and request.POST.get('stemail') and request.POST.get('staddress') and request.POST.get('stgender'):
           savest=crudst()
           savest.stname=request.POST.get('stname')
           savest.stemail=request.POST.get('stemail')
           savest.staddress=request.POST.get('staddress')
           #savest.stname=request.POST.get('stmobile')
           savest.stgender=request.POST.get('stgender')
           savest.save()
           #messages.success(request,"+savest.stname+" is saved succesfully")
           #messages.success(request, _("Parts database uploaded for processing"))
           return redirect('/')
    else:
            return render(request,"create.html")

def delete_st(request, id):
   emp = crudst.objects.get(id = id)
   emp.delete()
   return redirect('/')

def edit(request, id):  
    employee = crudst.objects.get(id=id)  
    return render(request,'edit.html', {'employee1':employee})

def update(request, id):  
    employee = crudst.objects.get(id=id)  
    form = crudform(request.POST, instance = employee)  
    if form.is_valid():  
        form.save()  
        return redirect("/")  
    return render(request, 'edit.html', {'employee': employee}) 

