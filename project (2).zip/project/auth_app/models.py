from django.db import models

# Create your models here.
class Auth(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    username = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    password = models.CharField(max_length=20)
    re_password = models.CharField(max_length=20)

    # class Meta:
    #     db_table = "Auth"

    
