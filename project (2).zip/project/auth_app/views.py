from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib import messages
from django.contrib.auth.models import User, auth
from django.contrib.auth import authenticate
from auth_app.models import Auth
#from auth_app.forms import AuthForm


# Create your views here.

def home(request):
    #return HttpResponse('Hi, this is where an individual post will be. mohit')
    return render(request, 'auth/home.html')

def login(request):
    if request.method == 'POST':
            username= request.POST['username']            
            password= request.POST['password']

            user = authenticate(username=username, password=password)
            if user is not None:
                if user.is_active:
                    login(request, user)
                    # Redirect to a success page.
                    return redirect('/')
                else:
                    # Return a 'disabled account' error message
                    return redirect('/')
            else:
                # Return an 'invalid login' error message.
                print('dsfsf')

            
    else:
        return render(request, 'auth/login.html')

def signup(request):
    if request.method == 'POST':
            fi_name= request.POST.get('f_name')            
            last_name= request.POST['last_name']
            username = request.POST.get('username')
            email = request.POST.get('email')
            password = request.POST.get('password')
            confirm_password = request.POST.get('confirm_password')

            user = Auth.objects.update_or_create(username=username, email=email, last_name=last_name, first_name=fi_name, password=password, re_password=confirm_password)
            user.save()
            #messages.success(request,"+savest.stname+" is saved succesfully")
            #messages.success(request, _("Parts database uploaded for processing"))
            return redirect('/')
    else:
        
        return render(request, 'auth/signup.html')

def handalsighnup(request):
    try:
        if request.method == 'POST':
            fi_name= request.POST.get('f_name')            
            last_name= request.POST['last_name']
            username = request.POST.get('username')
            email = request.POST.get('email')
            password = request.POST.get('password')
            confirm_password = request.POST.get('confirm_password')

            if password==confirm_password:
                Auth.objects.update_or_create(username=username, email=email, last_name=last_name, first_name=fi_name, password=password, re_password=confirm_password)
                print('user created')
            else:
                #print('user not created')
                messages.info(request, 'password must be same')
            
            return render(request, 'auth/signup.html')
        else:
            return render(request, 'auth/signup.html')
    except Exception as e:
        print("error:::", e)

       

    