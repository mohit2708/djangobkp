from django import forms
from auth_app.models import Auth

class AuthForm(forms.ModelForm):

    class Meta():
        model = Auth
        #fields = ('email','first_name','last_name')
        fields = "__all__"