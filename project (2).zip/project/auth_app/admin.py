from django.contrib import admin
from auth_app.models import Auth

# Register your models here.
admin.site.register(Auth)