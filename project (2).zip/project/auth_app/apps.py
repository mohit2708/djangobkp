from django.apps import AppConfig


class AuthAppConfig(AppConfig):
    name = 'auth_app'
